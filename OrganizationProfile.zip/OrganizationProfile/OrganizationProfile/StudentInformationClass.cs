﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrganizationProfile
{
    internal class StudentInformationClass
    {


        public static long SetStudentNo = 0;
        public static long SetContactNo = 0;
        public static string SetProgram = "";
        public static string SetGender = "";
        public static string SetBirthday = "";
        public static string SetFullName = "";
        public static int SetAge { get; set; } = 0;
    }
}


