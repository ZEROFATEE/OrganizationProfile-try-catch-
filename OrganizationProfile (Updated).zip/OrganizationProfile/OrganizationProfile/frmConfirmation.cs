﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OrganizationProfile
{
    public partial class frmConfirmation : Form
    {
        private string _fullName;
        private long _studentNo;
        private string _program;
        private string _gender;
        private int _age;
        private DateTime _birthday;
        private long _contactNo;
        private frmRegistration _registrationForm;


        public frmConfirmation(string fullName, long studentNo, string program, string gender, int age, DateTime birthday, long contactNo, frmRegistration registrationForm)
        {
            InitializeComponent();
            _fullName = fullName;
            _studentNo = studentNo;
            _program = program;
            _gender = gender;
            _age = age;
            _birthday = birthday;
            _contactNo = contactNo;
            _registrationForm = registrationForm;
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            
            MessageBox.Show("Registration Confirmed!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            _registrationForm.ClearInputFields();

            this.Close();

        }

        private void frmConfirmation_Load(object sender, EventArgs e)
        {
            lblStudentNo.Text = _studentNo.ToString();
            lblName.Text = _fullName;
            lblProgram.Text = _program;
            lblAge.Text = _age.ToString();
            lblBirthday.Text = _birthday.ToString("yyyy-MM-dd");
            lblGender.Text = _gender;
            lblContactNo.Text = _contactNo.ToString();
        }
    }
}
